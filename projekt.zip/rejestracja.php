<?php
  session_start();
  require_once "connect.php";
  mysqli_report(MYSQLI_REPORT_STRICT); //ograniczenie błędów wyswietlanych o tym w jakiej linii jaki błąd ( nie chcemy tego dla uzytkownikow)

  ?>
  <link rel="stylesheet" href="style.css" type="text/css">
  <style>
  body { background-image: url("index.png");
  background-size: 1200px;
  }
  </style>
<?php

  if(isset($_POST['email'])) //sprawdzamy czy istnieje jedna zmienna, bo jesli 1 istanieje to reszta tez, bo powstaeje ta zmienna po submicie
  {
    //udana walidacja :
    $wszystko_OK=true; //jesli bedzie wszystko ok, to ta wertosc pozwoli nam na wyslanie danych do bazy, jak nie to nie wysylamy do bazy
    $login=$_POST['login'];
    //sprawdzenie dlugosci loginu
    if((strlen($login)<3) || (strlen($login)>20))
    {
      $wszystko_OK=false;
      $_SESSION['e_login']="Login musi posiadac od 3 do 20 znakow!";

    }
    //sprawdzanie alfanumeryczne loginu
    if(ctype_alnum($login)==false)
    {
      $wszystko_OK=false;
      $_SESSION['e_login']="Login moze skladac sie tylko z liter i cyfr( bez polskich znakow )";
    }
    //sprawdz poprawnosc email:
    $email=$_POST['email'];
    $emailB=filter_var($email,FILTER_SANITIZE_EMAIL); //filtr do adresów mailowych
    if((filter_var($emailB,FILTER_VALIDATE_EMAIL)==false) || ($emailB!=$email)) //jesli sie zmienil
    {
      $wszystko_OK=false;
      $_SESSION['e_email']="Podaj poprawny email";
    }
    //sprawdz poprawnosc hasla
    $haslo1=$_POST['haslo1'];
    $haslo2=$_POST['haslo2'];
    if((strlen($haslo1)<8) || (strlen($haslo1)>20))
    {
      $wszystko_OK=false;
      $_SESSION['e_haslo']="Haslo musi posiadac miedzy 8 a 20 znakow";
    }
    if($haslo1!=$haslo2)
    {
      $wszystko_OK=false;
      $_SESSION['e_haslo']="Hasla sie roznia";
    }
    //hashowanie
    $haslo_hash=password_hash($haslo1,PASSWORD_DEFAULT);

    //Czy zaakceptowano regulamin?
    if(!isset($_POST['regulamin']))
    {
      $wszystko_OK=false;
      $_SESSION['e_regulamin']="Potwierdz akceptacje regulaminu";
    }

    //Sprawdzanie recaptchy
    $sekret="6LfanSgTAAAAAAHmWXnlqFgch9mslAzZJ5A5oRm0";
    $sprawdz=file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$sekret.'&response='.$_POST['g-recaptcha-response']);
    $odpowiedz=json_decode($sprawdz);

    if($odpowiedz->success==false)
    {
      $wszystko_OK=false;
      $_SESSION['e_bot']="Potwierdz, ze nie jestes botem";
    }
    //pamietanie wpisywanych danych:
    $_SESSION['stored_login']=$login;
    $_SESSION['stored_email']=$email;
    $_SESSION['stored_haslo1']=$haslo1;
    $_SESSION['stored_haslo2']=$haslo2;
    if(isset($_POST['regulamin'])) $_SESSION['stored_regulamin']=true;





    try // testowanie try catch, do rzucania i łapania błędów i późniejszego wyświetlania // ostatecznie bardziej intuicyjnie robienie $_SESSION['error'] i potem echowanie if isset
     {
        $polaczenie = new mysqli($host,$db_user,$db_password, $db_name);
        if ($polaczenie->connect_errno!=0)
        {
           throw new Exception(mysqli_connect_errno());
        }
        else
        {
          //czy email juz istnieje?
          $rezultat=$polaczenie->query("SELECT nr_id_konta FROM konta WHERE email='$email'");

          if(!$rezultat) throw new Exception($polaczenie->error);

          $ile_takich_maili=$rezultat->num_rows;
          if($ile_takich_maili>0)
          {
            $wszystko_OK=false;
            $_SESSION['e_email']="istnieje juz konto przypisane do tego adresu email";
          }
          //czy login juz istnieje?
          $rezultat=$polaczenie->query("SELECT nr_id_konta FROM konta WHERE login='$login'");

          if(!$rezultat) throw new Exception($polaczenie->error);

          $ile_takich_loginow=$rezultat->num_rows;
          if($ile_takich_loginow>0)
          {
            $wszystko_OK=false;
            $_SESSION['e_login']="istnieje juz konto przypisane do tego loginu";
          }
          // jesli sie udalo ( nie bylo błędów)
            if($wszystko_OK==true)
            {
              //testy zaliczone, dodajemy usera do bazy
              if($polaczenie->query("INSERT INTO `konta`( `pracownik`, `login`, `email`, `hasło`) VALUES ('0','$login','$email','$haslo_hash')"))
              {
                $_SESSION['udana_rejestracja']=true;
                if(isset($_SESSION['zalogowany_pracownik'])) //jesli jestesmy zalogowanym pracownikime
                {
                  header('Location: konto_pracownik.php');
                }
                else {
                  header('Location: witamy.php');
                }

              }
              else {
                throw new Exception ($polaczenie->error);
              }
            }
          $polaczenie->close();
        }
    }
    catch(Exception $e) //łapanie wyjatkow ktore pojawia sie wyzej i pokazywanie ich
    {
      echo '<span style="color:red;">blad serwera! przepraszamy za niedogodnosci i prosimy o rejestracje w innym terminie</span>';
      echo '<br /> Informacja developerska: '.$e; //tutaj tez mozemy zakomentowac aby wiecej info na temat błedów nie było
    }
  }
 ?>

 <!DOCTYPE HTML>
 <html lang="pl">
 <head>
     <meta charset="utf-8" />
     <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
     <title> Rejestracja </title>
     <script src='https://www.google.com/recaptcha/api.js'></script>
     <style>
     .error
     {
        color:red;
        margin-top: 10px;
        margin-bottom: 10px;
     }
     </style>

</head>

<body>
  <div id="container">
        <form method="post">
                                    Login: <br /><input type="text" value="<?php
                                    if(isset($_SESSION['stored_login']))
                                    {
                                      echo $_SESSION['stored_login'];
                                      unset($_SESSION['stored_login']);
                                    }
                                    ?>" name="login" /><br />
                                    <?php
                                    if(isset($_SESSION['e_login']))
                                    {
                                      echo '<div class="error">'.$_SESSION['e_login'].'</div>';
                                      unset($_SESSION['e_login']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic bledy
                                    }
                                     ?>
                                    E-mail:<br /><input type="text" value="<?php
                                    if(isset($_SESSION['stored_email']))
                                    {
                                      echo $_SESSION['stored_email'];
                                      unset($_SESSION['stored_email']);
                                    }
                                    ?>" name="email" /><br />
                                    <?php
                                    if(isset($_SESSION['e_email']))
                                    {
                                      echo '<div class="error">'.$_SESSION['e_email'].'</div>';
                                      unset($_SESSION['e_email']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic bledy
                                    }
                                     ?>
                                    Hasło: <br /><input type="password" value="<?php
                                    if(isset($_SESSION['stored_haslo1']))
                                    {
                                      echo $_SESSION['stored_haslo1'];
                                      unset($_SESSION['stored_haslo1']);
                                    }
                                    ?>" name="haslo1" /><br />
                                    <?php
                                    if(isset($_SESSION['e_haslo']))
                                    {
                                      echo '<div class="error">'.$_SESSION['e_haslo'].'</div>';
                                      unset($_SESSION['e_haslo']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic bledy
                                    }
                                     ?>
                                    Powtórz Hasło: <br /><input type="password" value="<?php
                                    if(isset($_SESSION['stored_haslo2']))
                                    {
                                      echo $_SESSION['stored_haslo2'];
                                      unset($_SESSION['stored_haslo2']);
                                    }
                                    ?>" name="haslo2" /><br />
                                    <?php
                                    if(isset($_SESSION['e_haslo']))
                                    {
                                      echo '<div class="error">'.$_SESSION['e_haslo'].'</div>';
                                      unset($_SESSION['e_haslo']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic bledy
                                    }
                                     ?>
                                    <label>
                                      <br /><input type="checkbox" name="regulamin" <?php
                                  if(isset($_SESSION['stored_regulamin']))
                                  {
                                    echo "checked";
                                    unset($_SESSION['stored_regulamin']);
                                  }
                                  ?>/>Akceptuję regulamin hotelu<br />
                                    </label>

                                    <?php
                                    if(isset($_SESSION['e_regulamin']))
                                    {
                                      echo '<div class="error">'.$_SESSION['e_regulamin'].'</div>';
                                      unset($_SESSION['e_regulamin']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic bledy
                                    }
                                     ?>

                                    <div class="g-recaptcha" data-sitekey="6LfanSgTAAAAAMsV7YOGr7dOUBGCCvNsEEPSDIxx"></div>
                                    <?php
                                    if(isset($_SESSION['e_bot']))
                                    {
                                      echo '<div class="error">'.$_SESSION['e_bot'].'</div>';
                                      unset($_SESSION['e_bot']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic bledy
                                    }
                                     ?>
                                    <br />

                                    <input type="submit" value="Zarejestruj sie" />


                </form>
                <?php
                    if(isset($_SESSION['zalogowany_pracownik']))
                    {
                      ?><form action="konto_pracownik.php" method="post">
                        <input type="submit" value="Wróć "></input>
                      <?php
                    }
                    else {
                      ?><form action="index.php" method="post">
                        <input type="submit" value="Wróć "></input>
                      <?php
                    }
                     ?>
                   </div>





</body>
</html>
