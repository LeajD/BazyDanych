<?php
session_start();

?>
<link rel="stylesheet" href="style.css" type="text/css">
<style>
body { background-image: url("31.png");
background-size: 1400px;
}
</style>
<?php
if(!isset($_SESSION['zalogowany_pracownik']))
{
  header('Location:konto.php');
}
error_reporting(E_ERROR);
require_once "connect.php";
$imie=$_POST['imie'];
$imie= htmlentities($imie, ENT_QUOTES, "UTF-8");

$nazwisko=$_POST['nazwisko'];
$nazwisko= htmlentities($nazwisko, ENT_QUOTES, "UTF-8");
  session_start();
  require_once "connect.php";
  $id=$_SESSION['id'];
  ?>

 <!DOCTYPE HTML>
 <html lang="pl">
 <head>
     <meta charset="utf-8" />
     <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
     <title> Historia Rezerwacji </title>
</head>

<body>
  <div id="container">
      <?php
          if(isset($_SESSION['zalogowany_pracownik']))
          {
            ?><form action="konto_pracownik.php" method="post">
              <input type="submit" value="Wróć "></input>
            <?php
          }
          else {
            ?><form action="index.php" method="post">
              <input type="submit" value="Wróć "></input>
            <?php
          }
           ?>
      <form method="post">


  </form>

            <?php

            session_start();
                if(isset($_POST['potwierdz']))
                {
                $polaczenie = @new mysqli($host,$db_user,$db_password,$db_name); //@- wycisza błędy spowodowane przez dalsze instruckje //ustanowienie polaczenia przez mysqli przez przesłanie danych //rezerwuje nowa pamiec, a mysqli to metoda
                $sql="SELECT * FROM klienci WHERE '$imie'=klienci.imię && '$nazwisko'=klienci.nazwisko ";
                $rezultat=@$polaczenie->query($sql);
                $wiersz = $rezultat->fetch_assoc();
                $ile_rezultatow=$rezultat->num_rows; //zbieramy ilosc wystapien w tabeli
                if($ile_rezultatow=='0')
                {
                  $_SESSION['error_rezultatow']="Nie znaleziono uzytkownika o takim imieniu i nazwisku!";
                }
                else {
                  unset($_SESSION['error_rezultatow']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic bledy
                  $_SESSION['brak_error_rezultatow']="Poprawny użytkownik!<br />";
                  $poprawnosc++;
                  $_SESSION['poprawnosc']++;
                  $id=$wiersz['nr_id_klienta'];

                }
              }

            ?>

<form method="post">

               Podaj imię:<br />
               <input type="text" name="imie" value="<?php echo $imie; ?>" /><br />
               Podaj nazwisko:<br />
                   <input type="text" name="nazwisko" value="<?php echo $nazwisko; ?> " /><br /><br />
                   <?php
                   if(isset($_SESSION['error_rezultatow']))
                   {
                     echo '<div class="error" style="color:red">'.$_SESSION['error_rezultatow'].'</div>';
                     unset($_SESSION['error_rezultatow']);
                     ?><?php

                   }
                   if(isset($_SESSION['brak_error_rezultatow']))
                   {
                     echo '<div class="error" style="color:green">'.$_SESSION['brak_error_rezultatow'].'</div>';
                     ?><?php
                   }
                    ?>
<input type="submit" name="potwierdz" value="Potwierdź klienta" />


<?php
  echo "<br /><br />Obecne rezerwacje:<br /><br />";


    $polaczenie = @new mysqli($host,$db_user,$db_password,$db_name); //@- wycisza błędy spowodowane przez dalsze instruckje //ustanowienie polaczenia przez mysqli przez przesłanie danych //rezerwuje nowa pamiec, a mysqli to metoda
    $sql="SELECT * FROM rezerwacje WHERE nr_id_klienta='$id'";
    $date = date('Y-m-d a', time());


    $rezultat=@$polaczenie->query($sql);
    $ile_rezultatow=$rezultat->num_rows; //zbieramy ilosc wystapien w tabeli
    if($ile_rezultatow==0)
    {
      echo '<div class="error" style="color:red">'."Jeśli nie widzisz swojej obecnej rezerwacji, nie masz uzupełnionych danych osobowych lub nie dokonałeś rezerwacji.<br />Kliknij poniżej, aby wrócić do panelu konta i uzupełnić swoje dane lub złożyć rezerwacje!</div>";

    }
    for($i=0; $i<$ile_rezultatow; $i++)
    {

      $wiersz[$i]=$rezultat->fetch_assoc();

      echo "---------------------------------------------<br />";
      echo "Indywidualny numer klienta: ".$wiersz[$i]['nr_id_klienta']."<br />";
      echo "Numer pokoju: ".$wiersz[$i]['nr_pokoju']."<br />";
      echo "Miejsce parkingowe: ".$wiersz[$i]['nr_parkingu']."<br />";
      echo "Data przyjazdu: ".$wiersz[$i]['data_przyjazdu']."<br />";
      echo "Numer odjazdu: ".$wiersz[$i]['data_odjazdu']."<br />";
      echo "Cena: ".$wiersz[$i]['cena']." zł"."<br />";
      echo "Czy opłacono?: ".$wiersz[$i]['opłacone']."<br />";
      echo "<br /><br />";
    }

   ?>

<br /><br />Rezerwacje z przeszłości:<br /><br />

<?php
    $polaczenie = @new mysqli($host,$db_user,$db_password,$db_name); //@- wycisza błędy spowodowane przez dalsze instruckje //ustanowienie polaczenia przez mysqli przez przesłanie danych //rezerwuje nowa pamiec, a mysqli to metoda
    $sql="SELECT * FROM historia_pobytow WHERE nr_id_klienta='$id'";

    $date = date('Y-m-d a', time());


    $rezultat=@$polaczenie->query($sql);
    $ile_rezultatow=$rezultat->num_rows; //zbieramy ilosc wystapien w tabeli
    if($ile_rezultatow==0)
    {
      echo '<div class="error" style="color:red">'."Jeśli nie widzisz swojej historii rezerwacji, oznacza to brak dokonanych rezerwacji.<br />Wróc do panelu konta i skontaktuj się z nami w razie dodatkowych pytań!</div>";

    }
    for($i=0; $i<$ile_rezultatow; $i++)
    {

      $wiersz[$i]=$rezultat->fetch_assoc();

      echo "Numer w historii pobytów: ".$wiersz[$i]['nr_id_pobytu']."<br />";
      echo "Numer rezerwacji: ".$wiersz[$i]['nr_rezerwacji']."<br />";
      echo "Indywidualny numer klienta: ".$wiersz[$i]['nr_id_klienta']."<br />";
      echo "Numer pokoju: ".$wiersz[$i]['nr_pokoju']."<br />";
      echo "Miejsce parkingowe: ".$wiersz[$i]['nr_parkingu']."<br />";
      echo "Data przyjazdu: ".$wiersz[$i]['data_zameldowania']."<br />";
      echo "Numer odjazdu: ".$wiersz[$i]['data_wymeldowania']."<br />";
      echo "Cena: ".$wiersz[$i]['cena']." zł"."<br />";
      echo "Czy opłacono?: ".$wiersz[$i]['opłacone']."<br /><br /><br /><br /><br />";


    }
    $polaczenie->close();
   ?>

<?php
unset($_SESSION['brak_error_rezultatow']);
 ?>
</body>
</html>
