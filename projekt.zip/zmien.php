<?php
  session_start();
  require_once "connect.php"; // bardzo ważne, żeby zrobic potem połączenie i porównywać rzeczy
  ?>
  <link rel="stylesheet" href="style.css" type="text/css">
  <style>
  body { background-image: url("31.png");
  background-size: 1400px;
  }
  </style>
  <?php
  error_reporting(E_ERROR);
  $id=$_SESSION['id'];

  $polaczenie = @new mysqli($host,$db_user,$db_password,$db_name); //@- wycisza błędy spowodowane przez dalsze instruckje //ustanowienie polaczenia przez mysqli przez przesłanie danych //rezerwuje nowa pamiec, a mysqli to metoda

  $_SESSION['stored_login']=$_POST['login'];
  $_SESSION['stored_email']=$_POST['email'];

  $wszystko_OK=true;
  $_SESSION['udana_zmiana']=false;
  if(isset($_POST['login'])) //sprawdzamy czy istnieje jedna zmienna, bo jesli 1 istanieje to reszta tez, bo powstaeje ta zmienna po submicie, a jesli istnieje to mozemy dalej robic polecenia, bez tego są wykonywane wcześniej i wyświetla się "pkoj zajety", a to było nieładne
  {
    try
    {
      //udana walidacja :
       //jesli bedzie wszystko ok, to ta wertosc pozwoli nam na wyslanie danych do bazy, jak nie to nie wysylamy do bazy
      $login=$_POST['login'];
      //sprawdzenie dlugosci loginu
      if((strlen($login)<3) || (strlen($login)>20))
      {
        $wszystko_OK=false;
        $_SESSION['e_login']="Login musi posiadac od 3 do 20 znakow!";
      }
      //sprawdzanie alfanumeryczne loginu
      if(ctype_alnum($login)==false)
      {
        $wszystko_OK=false;
        $_SESSION['e_login']="Login moze skladac sie tylko z liter i cyfr( bez polskich znakow )";
      }
      //sprawdz poprawnosc email:
      $email=$_POST['email'];
      $emailB=filter_var($email,FILTER_SANITIZE_EMAIL); //filtr do adresów mailowych
      if((filter_var($emailB,FILTER_VALIDATE_EMAIL)==false) || ($emailB!=$email)) //jesli sie zmienil
      {
        $wszystko_OK=false;
        $_SESSION['e_email']="Podaj poprawny email";
      }
      //sprawdz poprawnosc hasla
      $haslo1=$_POST['haslo1'];
      $haslo2=$_POST['haslo2'];
      if((strlen($haslo1)<8) || (strlen($haslo1)>20))
      {
        $wszystko_OK=false;
        $_SESSION['e_haslo']="Haslo musi posiadac miedzy 8 a 20 znakow";
      }
      if($haslo1!=$haslo2)
      {
        $wszystko_OK=false;
        $_SESSION['e_haslo']="Hasla sie roznia";
      }
      //hashowanie
      $haslo_hash=password_hash($haslo1,PASSWORD_DEFAULT);

        if ($polaczenie->connect_errno!=0)
        {
           throw new Exception(mysqli_connect_errno());
        }
        else
        {
          //czy email juz istnieje?
          $rezultat=$polaczenie->query("SELECT nr_id_konta FROM konta WHERE email='$email'");

          if(!$rezultat) throw new Exception($polaczenie->error);

          $ile_takich_maili=$rezultat->num_rows;
          if($ile_takich_maili>0)
          {
            $wszystko_OK=false;
            $_SESSION['e_email']="istnieje juz konto przypisane do tego adresu email";
          }
          //czy login juz istnieje?
          $rezultat=$polaczenie->query("SELECT nr_id_konta FROM konta WHERE login='$login'");

          if(!$rezultat) throw new Exception($polaczenie->error);

          $ile_takich_loginow=$rezultat->num_rows;
          if($ile_takich_loginow>0)
          {
            $wszystko_OK=false;
            $_SESSION['e_login']="istnieje juz konto przypisane do tego loginu";
          }
          // jesli sie udalo ( nie bylo błędów)

        }
    }
    catch(Exception $e) //łapanie wyjatkow ktore pojawia sie wyzej i pokazywanie ich
    {
      echo '<span style="color:red;">blad serwera! przepraszamy za niedogodnosci i prosimy o rejestracje w innym terminie</span>';
      echo "<br />";
      #echo '<br /> Informacja developerska: '.$e; //tutaj tez mozemy zakomentowac aby wiecej info na temat błedów nie było, takie info tylko dla devow
    }
    if($wszystko_OK=='true')
    {
      //testy zaliczone, dodajemy usera do bazy
      if($polaczenie->query(" UPDATE konta SET login='$login', email='$email', hasło='$haslo_hash' WHERE nr_id_konta='$id' "))
      {
        $_SESSION['udana_zmiana']=true;
      }
    }
  }
 ?>

 <!DOCTYPE HTML>
 <html lang="pl">
 <head>
     <meta charset="utf-8" />
     <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
     <title> Zmiana loginu/hasła/email </title>
</head>

<body>
  <div id="container">
    <?php
        if(isset($_SESSION['zalogowany_pracownik']))
        {
          ?><form action="konto_pracownik.php" method="post">
            <input type="submit" value="Wróć "></input>
          <?php
        }
        else {
          ?><form action="index.php" method="post">
            <input type="submit" value="Wróć "></input>
          <?php
        }
         ?>
</form>
  <form method="post">
    <br /><br />
    <?php // tutaj zbieramy $wiersz['login'] żeby móc go wyświetlić w inpucie
    $polaczenie = @new mysqli($host,$db_user,$db_password,$db_name); //@- wycisza błędy spowodowane przez dalsze instruckje //ustanowienie polaczenia przez mysqli przez przesłanie danych //rezerwuje nowa pamiec, a mysqli to metoda
    $sql="SELECT login,email FROM konta WHERE nr_id_konta='$id'";
    $rezultat=@$polaczenie->query($sql);
    $wiersz=$rezultat->fetch_assoc();
    ?>
  Nowy login: <br /><input type="text" placeholder="<?php echo $wiersz['login']; ?>" onfocus="this.placeholder=''" onblur="this.placeholder='<?php echo $wiersz['login']; ?>'" value="<?php session_start();
  if(isset($_SESSION['stored_login']))
  {
    echo $_SESSION['stored_login'];
    unset($_SESSION['stored_login']);
  }

  ?>" name="login" /><br /><br />
  <?php
  if(isset($_SESSION['e_login']))
  {
    echo '<div class="error" style="color:red">'.$_SESSION['e_login'].'</div>';
    unset($_SESSION['e_login']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic bledy
  }
   ?>
Nowy email: <br /><input type="text" placeholder="<?php echo $wiersz['email']; ?>" onfocus="this.placeholder=''" onblur="this.placeholder='<?php echo $wiersz['email']; ?>'" value="<?php
if(isset($_SESSION['stored_email']))
{
echo $_SESSION['stored_email'];
unset($_SESSION['stored_email']);
}
?>" name="email" /><br /><br />
 <?php
 if(isset($_SESSION['e_email']))
 {
   echo '<div class="error" style="color:red">'.$_SESSION['e_email'].'</div>';
   unset($_SESSION['e_email']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic bledy
 }
  ?>

  Nowe hasło: <br /><input type="password" name="haslo1" /><br /><br />
  Powtórz nowe hasło: <br /><input type="password" name="haslo2" /><br /><br />
                <?php
                if(isset($_SESSION['e_haslo']))
                {
                  echo '<div class="error" style="color:red">'.$_SESSION['e_haslo'].'</div>';
                  unset($_SESSION['e_haslo']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic bledy
                }
                 ?>

<br /><br />
  <input type="submit" value="Zaktualizuj" />

  <?php
  if($_SESSION['udana_zmiana']==true)
  {
    $_SESSION['udana_zmiana']="Udana zmiana danych!";
    echo '<div class="error" style="color:green">'.$_SESSION['udana_zmiana'].'</div>';
    unset($_SESSION['e_haslo']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic bledy
  }
    unset($_SESSION['e_haslo']);
    unset($_SESSION['e_login']);
    unset($_SESSION['e_email']);
    $polaczenie->close();
   ?>
</form>
</div>

</body>
</html>
