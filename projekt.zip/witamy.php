<?php
  session_start();
  ?>
  <link rel="stylesheet" href="style.css" type="text/css">
<?php
  if(!isset($_SESSION['udana_rejestracja']))
  {
    header('Location:index.php');
    exit(); //nie wykonywać reszty kodu pod spodem, bo i tka przechodzimy do innego pliku .php
  }
  else {
    unset($_SESSION['udana_rejestracja']);
  }

  //usuwamy zmienne sluzace do zapamietania wartosci w formularzu przy nieudanej walidacji danych
  if(isset($_SESSION['stored_login'])) unset($_SESSION['stored_login']);
  if(isset($_SESSION['stored_email'])) unset($_SESSION['stored_email']);
  if(isset($_SESSION['stored_haslo1'])) unset($_SESSION['stored_haslo1']);
  if(isset($_SESSION['stored_haslo2'])) unset($_SESSION['stored_haslo2']);
  if(isset($_SESSION['stored_regulamin'])) unset($_SESSION['stored_regulamin']);
  //usuwanie bledow rejestracji ( z przedrostkiem e)
  if(isset($_SESSION['e_nick'])) unset($_SESSION['e_nick']);
  if(isset($_SESSION['e_email'])) unset($_SESSION['e_email']);
  if(isset($_SESSION['e_haslo'])) unset($_SESSION['e_haslo']);
  if(isset($_SESSION['e_regulamin'])) unset($_SESSION['e_regulamin']);
  if(isset($_SESSION['e_bot'])) unset($_SESSION['e_bot']);

 ?>

 <!DOCTYPE HTML>
 <html lang="pl">
 <head>
     <meta charset="utf-8" />
     <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
     <title> Logowanie </title>
</head>

<body>
  <div id="container">
  <h2>Dziękujemy za rejestracje w serwisie! Możesz już zalogować się na swoje konto! </h2>
  <form action="index.php" method="post">
    <input type="submit" value="Zaloguj "></input>
  <br /><br />
  </div>
</body>
</html>
