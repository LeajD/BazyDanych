<?php
  session_start();
require_once "connect.php";
?>
<link rel="stylesheet" href="style.css" type="text/css">
<style>
body { background-image: url("21.png");
background-size: 1400px;
}
</style>
<?php
error_reporting(E_ERROR);


  $imie=$_POST['imie'];
  $nazwisko=$_POST['nazwisko'];
  $nr_dowodu=$_POST['nr_dowodu'];
  $nr_telefonu=$_POST['nr_telefonu'];
  $jezyk=$_POST['jezyk'];

  $id=$_SESSION['id'];

 // sprawdzanie warunków i łapanie wyjątków
 $polaczenie = @new mysqli($host,$db_user,$db_password,$db_name); //@- wycisza błędy spowodowane przez dalsze instruckje //ustanowienie polaczenia przez mysqli przez przesłanie danych //rezerwuje nowa pamiec, a mysqli to metoda
 $wszystko_OK=true;
 $_SESSION['udane_uzupelnienie']=false;
 if(isset($_POST['imie']))
 {
  try
  {
    //sprawdzanie czy tylko litery ma imie i nazwisko
    if (ctype_alpha($imie) == false || ctype_alpha($nazwisko) == false )
    {
        $wszystko_OK=false;
        $_SESSION['e_imie_nazwisko'] = 'Imie i Nazwisko muszą zawierać tylko litery!';
      }
      //czy nr dowodu juz istnieje?
        $rezultat=$polaczenie->query("SELECT * FROM klienci WHERE nr_dowodu='$nr_dowodu'");

        if(!$rezultat) throw new Exception($polaczenie->error);

        $ile_takich_nr_dowodow=$rezultat->num_rows;
        if($ile_takich_nr_dowodow>0)
        {
          $wszystko_OK=false;
          $_SESSION['e_nr_dowodu']="istnieje juz konto przypisane do tego nr_dowodu!";
        }
        if((strlen($nr_dowodu)!=9))
        {
          $wszystko_OK=false;
          $_SESSION['e_nr_dowodu']="nr dowodu nie jest 9-znakowy!";
        }
        //czy nr telefonu juz istnieje?
        $rezultat=$polaczenie->query("SELECT * FROM klienci WHERE nr_telefonu='$nr_telefonu'");
        $ile_takich_nr_telefonu=$rezultat->num_rows;
       if($ile_takich_nr_telefonu>0)
        {
          $wszystko_OK=false;
          $_SESSION['e_nr_telefonu']="istnieje juz konto przypisane do nr_telefonu!";
        }
        if((strlen($nr_telefonu)!=9))
        {
          $wszystko_OK=false;
        $_SESSION['e_nr_telefonu']="nr_telefonu nie jest 9-znakowy!";
        }
        //sprawdzanie czy tylko ltiery ma jezyk
        if (ctype_alpha($jezyk) == false)
        {
          $_SESSION['e_jezyk'] = 'język musi zawierać tylko litery!';
        }

        $rezultat=$polaczenie->query("SELECT * FROM klienci WHERE imię='$imie' && nazwisko='$nazwisko' ");

        $ile_takich_imion=$rezultat->num_rows;
        if($ile_takich_imion>0)
        {
          $wszystko_OK=false;
          $_SESSION['e_imie_nazwisko']="istnieje juz konto przypisane do tego imienia i nazwiska!";
        }
      }
      catch(Exception $e) //łapanie wyjatkow ktore pojawia sie wyzej i pokazywanie ich
      {
        echo '<span style="color:red;">blad serwera! przepraszamy za niedogodnosci i prosimy o rejestracje w innym terminie</span>';
        echo '<br /> Informacja developerska: '.$e; //tutaj tez mozemy zakomentowac aby wiecej info na temat błedów nie było
      }
      if($wszystko_OK=='true')
      {
        //sprawdzamy czy istnieje juz konto, jesli tak to UPDATE,jesli nie to INSERT INTO, Bo to nie jest tworzenie nowego konta, tylko uzupełnianie danych, takich jak imie nazwisko
        $sql="SELECT * FROM klienci WHERE nr_id_klienta='$id'";
        $rezultat=@$polaczenie->query($sql);
        $czy_istnieje=$rezultat->num_rows;
        if($czy_istnieje==1)
        {
          $polaczenie->query("UPDATE klienci SET imię='$imie',nazwisko='$nazwisko',nr_dowodu='$nr_dowodu',nr_telefonu='$nr_telefonu',język='$jezyk' WHERE nr_id_klienta='$id'");
          $_SESSION['udane_uzupelnienie']=true;
        }
        else{
              $polaczenie->query("INSERT INTO `klienci` (`nr_id_klienta`, `imię`, `nazwisko`, `nr_dowodu`, `nr_telefonu`, `język`)
              VALUES ('$id', '$imie', '$nazwisko', '$nr_dowodu', '$nr_telefonu', '$jezyk')");
              $_SESSION['udane_uzupelnienie']=true;
        }

      }

   }


   ?>



 <!DOCTYPE HTML>
 <html lang="pl">
 <head>
     <meta charset="utf-8" />
     <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
     <title> Twoje dane </title>
</head>

<body>
  <div id="container">

  <form action="konto.php" method="post">
    <input type="submit" value="Wróć "></input></form>
  <form method="post">
      Imię: <br /> <input type="text" name="imie"/> <br /><br />
      Nazwisko: <br /> <input type="text" name="nazwisko"/> <br /><br />
              <?php
              if(isset($_SESSION['e_imie_nazwisko']))
              {
                echo '<div class="error" style="color:red">'.$_SESSION['e_imie_nazwisko'].'</div>';
                unset($_SESSION['e_imie_nazwisko']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic bledy
              }
               ?>
      nr_dowodu<br/>(potrzebny do rezerwacji): <br /> <input type="text" name="nr_dowodu"/> <br /><br />
              <?php
              if(isset($_SESSION['e_nr_dowodu']))
              {
                echo '<div class="error" style="color:red">'.$_SESSION['e_nr_dowodu'].'</div>';
                unset($_SESSION['e_nr_dowodu']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic bledy
              }
               ?>
      nr_telefonu: <br /> <input type="text" name="nr_telefonu"/> <br /><br />
              <?php
              if(isset($_SESSION['e_nr_telefonu']))
              {
                echo '<div class="error" style="color:red">'.$_SESSION['e_nr_telefonu'].'</div>';
                unset($_SESSION['e_nr_telefonu']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic bledy
              }
               ?>
      język: <br /> <input type="text" name="jezyk"/> <br /><br />
                <?php
                if(isset($_SESSION['e_jezyk']))
                {
                  echo '<div class="error" style="color:red">'.$_SESSION['e_jezyk'].'</div>';
                  unset($_SESSION['e_jezyk']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic bledy
                }
                 ?>
      <input type ="submit" value="Zapisz" />


      <?php
      if($_SESSION['udane_uzupelnienie']==true)
      {
        $_SESSION['udane_uzupelnienie']="Udane uzupełnienie danych!";
        echo '<div class="error" style="color:green">'.$_SESSION['udane_uzupelnienie'].'</div>';
        $_SESSION['udane_uzupelnienie']==false;
      }
        unset($_SESSION['e_nr_dowodu']);
        unset($_SESSION['e_nr_telefonu']);
        unset($_SESSION['e_imie_nazwisko']);
        $polaczenie->close();
       ?>
  </form>
</div>

</body>
</html>
