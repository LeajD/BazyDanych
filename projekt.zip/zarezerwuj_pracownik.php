<?php

session_start();

?>
<link rel="stylesheet" href="style.css" type="text/css">
<style>
body { background-image: url("31.png");
background-size: 1400px;
}
</style>
<?php
if(!isset($_SESSION['zalogowany_pracownik']))
{
  header('Location:konto.php');
}
error_reporting(E_ERROR);
require_once "connect.php";

$imie=$_POST['imie'];
$imie= htmlentities($imie, ENT_QUOTES, "UTF-8"); //przeciwdziałanie SQL INJECTION !
$nazwisko=$_POST['nazwisko'];
$nazwisko= htmlentities($nazwisko, ENT_QUOTES, "UTF-8");

$nr_pokoju=$_POST['nr_pokoju'];
$miejsce_parkingowe=$_POST['miejsce_parkingowe'];
$miejsce_parkingowe= htmlentities($miejsce_parkingowe, ENT_QUOTES, "UTF-8");
$data_przyjazdu=$_POST['data_przyjazdu'];
$data_odjazdu=$_POST['data_odjazdu'];

$poprawnosc=0; //sprawdza poprawnosc pokojów i parkingów
$p=0; //do inkrementacji elementu w tablicy tabela
$b=0; //do inkrementacji elementu w tablicy tabela2
$tabela[22]=[]; //tabela przechowująca wolne pokoje
$tabela2[19]=[]; //tabela przechowujaca wolne parkingi
$date = date('Y-m-d', time());


 ?>

<!DOCTYPE HTML>
<html lang="pl">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title> Zarezerwuj pokój </title>
</head>

<body>
  <div id="container">
 <?php
     if(isset($_SESSION['zalogowany_pracownik']))
     {
       ?><form action="konto_pracownik.php" method="post">
         <input type="submit" value="Wróć "></input>
       <?php
     }
     else {
       ?><form action="index.php" method="post">
         <input type="submit" value="Wróć "></input>
       <?php
     }
      ?>
    </form>

<?php
        session_start();
            if(isset($_POST['potwierdz']))
            {

            $polaczenie = @new mysqli($host,$db_user,$db_password,$db_name); //@- wycisza błędy spowodowane przez dalsze instruckje //ustanowienie polaczenia przez mysqli przez przesłanie danych //rezerwuje nowa pamiec, a mysqli to metoda
            #$imie=$_POST['imie'];
            #$nazwisko=$_POST['nazwisko'];
            $sql="SELECT * FROM klienci WHERE '$imie'=klienci.imię && '$nazwisko'=klienci.nazwisko ";
            $rezultat=@$polaczenie->query($sql);
            $wiersz = $rezultat->fetch_assoc();
            $ile_rezultatow=$rezultat->num_rows; //zbieramy ilosc wystapien w tabeli
            if($ile_rezultatow=='0')
            {
              $_SESSION['error_rezultatow']="Nie znaleziono uzytkownika o takim imieniu i nazwisku!";
            }
            else {
              unset($_SESSION['error_rezultatow']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic bledy
              $_SESSION['brak_error_rezultatow']="Poprawny użytkownik!";
              $poprawnosc++;
              $_SESSION['poprawnosc']++;
              $id=$wiersz['nr_id_klienta'];

            }
          }

?>
<?php
 ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 //                                                    TA CZĘŚĆ ODPOWIADA ZA PODAWANIE IMIENIA I NAZWISKA
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ?>
        <form method="post">

                       Podaj imię:<br />
                       <input type="text" name="imie" value="<?php echo $imie; ?>" /><br />
                       Podaj nazwisko:<br />
                           <input type="text" name="nazwisko" value="<?php echo $nazwisko; ?> " /><br /><br />
                           <?php
                           if(isset($_SESSION['error_rezultatow']))
                           {
                             echo '<div class="error" style="color:red">'.$_SESSION['error_rezultatow'].'</div>';
                             unset($_SESSION['error_rezultatow']);
                             ?><h3><a href ="zarezerwuj_pracownik.php" ;>Wprowadź poprawnego użytkownika</a></h3><?php
                             exit();

                           }
                           if(isset($_SESSION['brak_error_rezultatow']))
                           {
                             echo '<div class="error" style="color:green">'.$_SESSION['brak_error_rezultatow'].'</div>';
                             ?><?php

                           }
                            ?>
                            <input type="submit" name="potwierdz" value="Zweryfikuj klienta" />

                          <?php
                          session_start(); // rozpoczynanie sesji w każdym paragrafie php bo inaczej były błędy, nie przechowywałlo między sesjami wszystkich zmiennych prawidłowo!
                          echo "<br />";

                            if (($data_odjazdu < $data_przyjazdu && $data_przyjazdu>=$date && $data_odjazdu>=$date ) || ( $data_odjazdu > $data_przyjazdu && $data_przyjazdu<=$date && $data_odjazdu<=$date ) || ( $data_odjazdu < $data_przyjazdu && $data_przyjazdu<=$date && $data_odjazdu<=$date ) || ( $data_odjazdu > $data_przyjazdu && $data_przyjazdu<=$date && $data_odjazdu>=$date ) || ( $data_odjazdu < $data_przyjazdu && $data_przyjazdu>=$date && $data_odjazdu<=$date ))
                                  {
                                    $_SESSION['e_daty']="Data przyjazdu nie może być później niż odjazdu!";
                                  } ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                   ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                   ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                   //                                                    TA CZĘŚĆ ODPOWIADA ZA PODAWANIE DATY
                                  ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                  ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                 ?>
                                                    <br />
                                         Data przyjazdu: <br /><input type="date" name="data_przyjazdu" value=<?php echo $data_przyjazdu; ?> min="2020-01-01" max="2020-12-30"/><br />
                                         Data odjazdu: <br /><input type="date" name="data_odjazdu" value=<?php echo $data_odjazdu; ?> min="2020-01-01" max="2020-12-30"/><br /><br />
                                                   <?php
                                                   session_start();
                                                   if(isset($_SESSION['e_daty']) ) // jesli był błąd w podawaniu daty
                                                   {
                                                     echo '<div class="error" style="color:red">'.$_SESSION['e_daty'].'</div>';
                                                     unset($_SESSION['e_daty']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic bledy
                                                     ?><h3><a href ="zarezerwuj_pracownik.php">Wybierz ponownie poprawną datę</a></h3><?php
                                                     exit();
                                                     ?>
                                                     <?php

                                                   }?>
                                                   <input type="submit" value="Zweryfikuj date" name="submit"/>
                                                  <br />
                                                  <br />


        <?php
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //                                                    TA CZĘŚĆ ODPOWIADA ZA AKCJE PO NACIŚNIĘCIU WERYFIKACJI DATY ( NAJPIERW WYŚWIETLANIE WOLNYCH POKOJÓW)
       ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
       ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        session_start();
        if(isset($_POST['submit']) ) //jeśli nacisnięto submit
        {

          echo "Wolne pokoje:<br />";
        $polaczenie = @new mysqli($host,$db_user,$db_password,$db_name);
        echo "<br />";
        $date = date('Y-m-d a', time());

        $sql="SELECT rezerwacje.nr_id_klienta,pokoje.nr_pokoju,pokoje.rodzaj_pokoju,pokoje.cena FROM pokoje,rezerwacje
        WHERE  (rezerwacje.nr_pokoju = pokoje.nr_pokoju && rezerwacje.status!='aktywny' && (('$data_przyjazdu'>rezerwacje.data_odjazdu && '$data_odjazdu'>rezerwacje.data_odjazdu) || ('$data_przyjazdu'<rezerwacje.data_przyjazdu && '$data_odjazdu'<rezerwacje.data_przyjazdu) )) ";
        $rezultat=@$polaczenie->query($sql);
        $ile_rezultatow=$rezultat->num_rows; //zbieramy ilosc wystapien w tabeli
        for($i=0; $i<$ile_rezultatow; $i++)
        {
          $wiersz[$i]=$rezultat->fetch_assoc();
          // sprawdzanie czy numer pokoju się powtarza, bo jeśli się powtarzał to potrafiło wyświetlić numer pokoju dostępny, bo np była późniejsza rezerwacja i jak sprawdzaliśmy wcześniejszą datą, to ona przechodziła nasz warunel - daty wcześniejsze , więc sprawdzanie ile razy wystąpiło i wyświetlanie tylko wtedy gdy ten pokój spełnia warunek ZAWSZE, TYLE RAZY ILE KWERENDA OBLICZY
          $test=$wiersz[$i]['nr_pokoju'];
          $zliczenia=0;
          $wyswietlone=0;
          $sql_liczba="SELECT * FROM rezerwacje WHERE $test=rezerwacje.nr_pokoju";
          $rezultat_liczby=@$polaczenie->query($sql_liczba);
          $ile_rezultatow_liczby=$rezultat_liczby->num_rows;

          for($x=0;$x<$ile_rezultatow;$x++)
          {
            if($wiersz[$x]['nr_pokoju']==$test)
              {
                  $zliczenia++;
              }
            if($ile_rezultatow_liczby==$zliczenia)
            {
              $zliczenia=0;
              if($nr_pokoju=$test)
              {
                echo "Pokój nr: ".$wiersz[$i]['nr_pokoju'].": ".$wiersz[$i]['rodzaj_pokoju'].",cena:  ".$wiersz[$i]['cena']."<br />";
              }

            }
          }
        }///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //                                                    TERAZ WYŚWIETLANIE WOLNYCH PARKINGÓW
       ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
       ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                echo "<br /><br />";
                echo "---------------------------------------<br />";
                echo "Wolne miejsca parkingowe:<br /><br />";
                $sql="SELECT rezerwacje.nr_parkingu,parkingi.miejsce, parkingi.id_parkingu,rezerwacje.data_przyjazdu,rezerwacje.data_odjazdu,rezerwacje.status,parkingi.cena FROM parkingi,rezerwacje
                WHERE  (rezerwacje.nr_parkingu = parkingi.id_parkingu && rezerwacje.status!='aktywny' && parkingi.status!='brak' && (('$data_przyjazdu'>rezerwacje.data_odjazdu && '$data_odjazdu'>rezerwacje.data_odjazdu) || ('$data_przyjazdu'<rezerwacje.data_przyjazdu && '$data_odjazdu'<rezerwacje.data_przyjazdu) )  )";
                $rezultat=@$polaczenie->query($sql);
                $ile_rezultatow=$rezultat->num_rows; //zbieramy ilosc wystapien w tabeli
                for($i=0; $i<$ile_rezultatow; $i++)
                {
                  $wiersz[$i]=$rezultat->fetch_assoc();
                  // sprawdzanie czy numer pokoju się powtarza, bo jeśli się powtarzał to potrafiło wyświetlić numer pokoju dostępny, bo np była późniejsza rezerwacja i jak sprawdzaliśmy wcześniejszą datą, to ona przechodziła nasz warunel - daty wcześniejsze , więc sprawdzanie ile razy wystąpiło i wyświetlanie tylko wtedy gdy ten pokój spełnia warunek ZAWSZE, TYLE RAZY ILE KWERENDA OBLICZY
                  $test=$wiersz[$i]['nr_parkingu'];
                  $zliczenia=0;
                  $wyswietlone=0;
                  $sql_liczba="SELECT * FROM rezerwacje WHERE $test=rezerwacje.nr_parkingu";
                  $rezultat_liczby=@$polaczenie->query($sql_liczba);
                  $ile_rezultatow_liczby=$rezultat_liczby->num_rows;

                  for($x=0;$x<$ile_rezultatow;$x++)
                  {
                    if($wiersz[$x]['nr_parkingu']==$test)
                      {
                          $zliczenia++;
                      }
                    if($ile_rezultatow_liczby==$zliczenia)
                    {
                      $zliczenia=0;
                        echo "Parking numer: ".$wiersz[$i]['miejsce']." cena: ".$wiersz[$i]['cena']." <br />";
                    }
                  }

                }

          }
                 ?>
                            Wybierz numer pokoju: <br /><input type="text" name="nr_pokoju"/><br />
                            Wybierz numer miejsca parkingowego: <br /><input type="text" name="miejsce_parkingowe"/><br />
                           <input type="submit" value="Rezerwuj" name="submit2"/>
                 </form>

<br />



                        <?php
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //TA CZĘŚĆ ODPOWIADA ZA AKCJE PO NACIŚNIĘCIU REZERWUJ -- czyli sprawdzenie  czy pokój znajduje siee ( i zliczanie ile razy, aby w przypadku wielokrotnego wystapienia wziac pod uwage ze moze byc pokoj niedostepny w terminie oraz ten sam pokoj dostepnym w innym ) w tablicy która zbierała wolne pokoje i to samo z parkingami
   ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                        session_start();
                        if(isset($_POST['submit2']))
                        {

                          $polaczenie = @new mysqli($host,$db_user,$db_password,$db_name); //@- wycisza błędy spowodowane przez dalsze instruckje //ustanowienie polaczenia przez mysqli przez przesłanie danych //rezerwuje nowa pamiec, a mysqli to metoda
                          $sql="SELECT rezerwacje.nr_id_klienta,pokoje.nr_pokoju,pokoje.rodzaj_pokoju,pokoje.cena FROM pokoje,rezerwacje
                          WHERE  (rezerwacje.nr_pokoju = pokoje.nr_pokoju && rezerwacje.status!='aktywny' && (('$data_przyjazdu'>rezerwacje.data_odjazdu && '$data_odjazdu'>rezerwacje.data_odjazdu) || ('$data_przyjazdu'<rezerwacje.data_przyjazdu && '$data_odjazdu'<rezerwacje.data_przyjazdu) )) ";
                          $rezultat=@$polaczenie->query($sql);
                          $ile_rezultatow=$rezultat->num_rows; //zbieramy ilosc wystapien w tabeli
                          for($i=0; $i<$ile_rezultatow; $i++)
                          {
                              $wiersz[$i]=$rezultat->fetch_assoc();
                              $test=$wiersz[$i]['nr_pokoju'];
                              $zliczenia=0;
                              $wyswietlone=0;
                              $sql_liczba="SELECT * FROM rezerwacje WHERE $test=rezerwacje.nr_pokoju";
                              $rezultat_liczby=@$polaczenie->query($sql_liczba);
                              $ile_rezultatow_liczby=$rezultat_liczby->num_rows;

                              for($x=0;$x<$ile_rezultatow;$x++)
                              {
                                if($wiersz[$x]['nr_pokoju']==$test)
                                  {
                                      $zliczenia++;
                                  }
                                if($ile_rezultatow_liczby==$zliczenia)
                                {
                                  $zliczenia=0;
                                  if($nr_pokoju=$test)
                                  {
                                    $tabela[$b]=$wiersz[$i]['nr_pokoju'];
                                    $b++;
                                  }

                                }
                              }
                            }
                              $nr_pokoju=$_POST['nr_pokoju'];
                              $sql="SELECT rezerwacje.nr_parkingu,parkingi.miejsce, parkingi.id_parkingu,rezerwacje.data_przyjazdu,rezerwacje.data_odjazdu,rezerwacje.status,parkingi.cena FROM parkingi,rezerwacje
                              WHERE  (rezerwacje.nr_parkingu = parkingi.id_parkingu && rezerwacje.status!='aktywny' && (('$data_przyjazdu'>rezerwacje.data_odjazdu && '$data_odjazdu'>rezerwacje.data_odjazdu) || ('$data_przyjazdu'<rezerwacje.data_przyjazdu && '$data_odjazdu'<rezerwacje.data_przyjazdu) )  )";
                              $rezultat=@$polaczenie->query($sql);
                              $ile_rezultatow=$rezultat->num_rows; //zbieramy ilosc wystapien w tabeli
                              for($i=0; $i<$ile_rezultatow; $i++)
                              {
                                $wiersz[$i]=$rezultat->fetch_assoc();
                                // sprawdzanie czy numer pokoju się powtarza, bo jeśli się powtarzał to potrafiło wyświetlić numer pokoju dostępny, bo np była późniejsza rezerwacja i jak sprawdzaliśmy wcześniejszą datą, to ona przechodziła nasz warunel - daty wcześniejsze , więc sprawdzanie ile razy wystąpiło i wyświetlanie tylko wtedy gdy ten pokój spełnia warunek ZAWSZE, TYLE RAZY ILE KWERENDA OBLICZY
                                $test=$wiersz[$i]['nr_parkingu'];
                                $zliczenia=0;
                                $wyswietlone=0;
                                $sql_liczba="SELECT * FROM rezerwacje WHERE $test=rezerwacje.nr_parkingu";
                                $rezultat_liczby=@$polaczenie->query($sql_liczba);
                                $ile_rezultatow_liczby=$rezultat_liczby->num_rows;

                                for($x=0;$x<$ile_rezultatow;$x++)
                                {
                                  if($wiersz[$x]['nr_parkingu']==$test)
                                    {
                                        $zliczenia++;
                                    }
                                  if($ile_rezultatow_liczby==$zliczenia)
                                  {
                                    $zliczenia=0;
                                      $tabela2[$p]=$wiersz[$i]['miejsce'];
                                      $p++;
                                  }
                                }

                              }


                         // sprawdzanie poprawnosci pokojow
                         $rozmiar=count($tabela)+1; // pobieranie wielkości tabeli +1, bo idexowanie od 0
                         $nr_pokoju2=$nr_pokoju;
                         for($i=0;$i<$rozmiar+1;$i++)
                         {
                           if ($nr_pokoju2==$tabela[$i])
                           {
                             $poprawnosc++;
                           }
                         }
                         if($poprawnosc>'1') // jesli sie powtórzył pokoj, to zostaw przy wartości 1, bo to wartość która weryfikuje pokoj jako dostepny
                         {
                            $poprawnosc=1;
                         }
                         $rozmiar2=count($tabela2)+1;
                         $nr_parkingu2=$miejsce_parkingowe;
                         for($i=0;$i<$rozmiar2+1;$i++)
                         {
                           if($nr_parkingu2==$tabela2[$i])
                           {
                             $poprawnosc++;
                           }
                         }
                         if($poprawnosc>'2') // jesli sie powtórzył parking, to zostaw przy wartości 2, bo może się parking powtórzyć , a to wartość która weryfikuje parking jako dostepny
                         {
                             $poprawnosc=2;
                         }
                                  //sumujemy ceny za pokój i parking
                                  $sql="SELECT * FROM pokoje WHERE nr_pokoju='$nr_pokoju'";
                                  $rezultat=@$polaczenie->query($sql);
                                  $wiersz=$rezultat->fetch_assoc();
                                  $cena1=$wiersz['cena'];
                                    $sql="SELECT * FROM parkingi WHERE miejsce='$miejsce_parkingowe'";
                                    $rezultat=@$polaczenie->query($sql);
                                    $wiersz=$rezultat->fetch_assoc();
                                    $cena2=$wiersz['cena'];
                                      $cena3=$cena1+$cena2;
                                          $sql="SELECT * FROM klienci WHERE '$imie'=klienci.imię && '$nazwisko'=klienci.nazwisko ";
                                          $rezultat=@$polaczenie->query($sql);
                                          $wiersz = $rezultat->fetch_assoc();
                                            $id=$wiersz['nr_id_klienta'];

if($poprawnosc=='2')
{
      unset($_SESSION['brak_error_rezultatow']);
      if($miejsce_parkingowe==0) // można zarezerwaować bez parkingu, wtedy pole zostawiamy puste, i wysyłamy do tabeli w mysql z index 0 jako brak miejsca
      {
        $polaczenie->query("INSERT INTO `rezerwacje`( `nr_id_klienta`, `nr_pokoju`, `nr_parkingu`, `data_przyjazdu`, `data_odjazdu`, `cena`, `opłacone`, `status`) VALUES ( '$id', '$nr_pokoju', '0', '$data_przyjazdu', '$data_odjazdu', '$cena3', 'tak','tak')");
      } // tu nie potrzeba else, bo jesli nie ma miejsca parkingowego to i tak poniższa komenda nie przejdzie                                                                                              # tutaj
        $polaczenie->query("INSERT INTO `rezerwacje`( `nr_id_klienta`, `nr_pokoju`, `nr_parkingu`, `data_przyjazdu`, `data_odjazdu`, `cena`, `opłacone`, `status`) VALUES ( '$id', '$nr_pokoju','$miejsce_parkingowe', '$data_przyjazdu', '$data_odjazdu', '$cena3', 'tak','tak')");
        unset($_SESSION['error']); // wyciszam error, bo jak sie wypełni date i potem submituje to po wypełnieniu pokoju i parkingu nie pamięta że data jest wybrana
        $_SESSION['success']="Rezerwacja udana";
                                                                                        }
          else {
          if(isset($_POST['submit2']))
          {
                $_SESSION['not_ok']=" Podałeś zły numer pokoju i parkingu";
                echo '<div class="error" style="color:RED">'.$_SESSION['not_ok'].'</div>';
                unset($_SESSION['not_ok']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic ble
                exit();
          }
          }
$polaczenie->close();
}


?>


<?php

if(isset($_SESSION['success']))
{
  echo '<div class="error" style="color:green">'.$_SESSION['success'].'</div>';
  unset($_SESSION['success']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic bledy
}

  unset($_SESSION['blad']);
  unset($_SESSION['e_status_pokoj']);
  unset($_SESSION['error']);
  unset($_SESSION['error_rezultatow']);

 ?>
</div>
</body>
</html>
