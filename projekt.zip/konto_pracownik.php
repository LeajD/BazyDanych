<?php
  session_start();
  require_once "connect.php"; // bardzo ważne, żeby zrobic potem połączenie i porównywać rzeczy
  ?>
  <link rel="stylesheet" href="style.css" type="text/css">
  <style>
  body { background-image: url("21.png");
  background-size: 1400px;
 }
</style>
<?php

  $id=$_SESSION['id'];
  $date = date('Y-m-d a', time()); // przypisanie daty do zmiennej w odpowiednim formacie


  if(!isset($_SESSION['zalogowany'])) //nie jestesmy zalogowani
  {
    header('Location:index.php');
    exit();
  }

 ?>
 <!DOCTYPE HTML>
 <html lang="pl">
 <head>
     <meta charset="utf-8" />
     <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
     <title> Konto Pracownik </title>
</head>

<body>
  <div id="container">
<?php

  //sprawdzanie przestarzalych rezerwacji: //sprawdzic ile rekordow, zrobic petle for, dla kazdego pobierac do wiersza i przesylac przez insert into
  $polaczenie = @new mysqli($host,$db_user,$db_password,$db_name); //@- wycisza błędy spowodowane przez dalsze instruckje //ustanowienie polaczenia przez mysqli przez przesłanie danych //rezerwuje nowa pamiec, a mysqli to metoda


        $polaczenie = @new mysqli($host,$db_user,$db_password,$db_name); //@- wycisza błędy spowodowane przez dalsze instruckje //ustanowienie polaczenia przez mysqli przez przesłanie danych //rezerwuje nowa pamiec, a mysqli to metoda
        $date = date('Y-m-d', time());
        /////////////////////////     zmiana statusu rezerwacji, pokojów i parkingów        \\\\\\\\\\\\\\\\\\\\\\\\
        $sql="UPDATE `rezerwacje` SET `status`='aktywne' WHERE data_odjazdu>='$date' && data_przyjazdu<='$date'";
        $sql2="UPDATE pokoje INNER JOIN rezerwacje ON rezerwacje.nr_pokoju=pokoje.nr_pokoju
        SET pokoje.status='aktywne' WHERE  rezerwacje.data_odjazdu>'$date' && rezerwacje.data_przyjazdu<'$date' ";
        $sql3="UPDATE parkingi INNER JOIN rezerwacje ON rezerwacje.nr_parkingu=parkingi.id_parkingu
        SET parkingi.status='aktywne' WHERE  rezerwacje.data_odjazdu>'$date' && rezerwacje.data_przyjazdu<'$date'";
        $rezultat2=@$polaczenie->query($sql);
        $rezultat2=@$polaczenie->query($sql2);
        $rezultat2=@$polaczenie->query($sql3);

            $sql99="SELECT * FROM rezerwacje WHERE rezerwacje.data_odjazdu<'$date'";
            $rezultat=@$polaczenie->query($sql99);
            $ile_rezultatow=$rezultat->num_rows; //zbieramy ilosc wystapien w tabeli
            for($i=0;$i<$ile_rezultatow;$i++)
            {
              $wiersz[$i]=$rezultat->fetch_assoc();
              if($date>$wiersz[$i]['data_odjazdu'])
              {
                    $nr_rezerwacji=$wiersz[$i]['nr_rezerwacji'];
                    $nr_id_klienta=$wiersz[$i]['nr_id_klienta'];
                    $nr_pokoju=$wiersz[$i]['nr_pokoju'];
                    $nr_parkingu=$wiersz[$i]['nr_parkingu'];
                    $data_przyjazdu=$wiersz[$i]['data_przyjazdu'];
                    $data_odjazdu=$wiersz[$i]['data_odjazdu'];
                    $cena=$wiersz[$i]['cena'];
                    $oplacone=$wiersz[$i]['opłacone'];
                    $sql98="INSERT INTO `historia_pobytow`(`nr_id_pobytu`, `nr_rezerwacji`, `nr_id_klienta`, `nr_pokoju`, `nr_parkingu`, `data_zameldowania`, `data_wymeldowania`, `cena`, `opłacone`, `timestamp`)
                    VALUES (NULL,'$nr_rezerwacji','$nr_id_klienta','$nr_pokoju','$nr_parkingu','$data_przyjazdu','$data_odjazdu','$cena','$oplacone',NOW())";
                    $rezultat98=@$polaczenie->query($sql98);
                    $sql97="DELETE FROM rezerwacje WHERE '$date'>'$data_odjazdu' ORDER BY rezerwacje.data_odjazdu LIMIT 1 "; //DELETE FROM rezerwacje
                    $rezultat97=@$polaczenie->query($sql97);
                    $polaczenie->query("UPDATE pokoje SET status='wolny' WHERE nr_pokoju='$nr_pokoju' ");
                    $polaczenie->query("UPDATE parkingi SET status='wolne' WHERE miejsce='$nr_parkingu' && status!='brak' ");
                    $polaczenie->query("DELETE FROM historia_pobytow WHERE historia_pobytow.timestamp <= now() - interval 365 day "); //usuwanie rekorów po 365 dniach !

                  }
                }
                ?>
                <form action="logout.php" method="get">
                   <input type="submit" value="Wyloguj się"></input></form>
                   <?php    echo "<h3>Witaj pracowniku ".$_SESSION['login']."</h3>";?>

                 <form action="dane.php" method="get">
                 <input type="submit" value="Zobacz swoje dane"></input></form>
                 <form action="zmien.php" method="get">
                 <input type="submit" value="Zmień swoje dane"></input></form>
                 <form action="rejestracja.php" method="get">
                 <input type="submit" value="Dodaj użytkownika"></input></form>
                 <form action="historia_rezerwacji_pracownik.php" method="get">
                 <input type="submit" value="Przeglądaj rezerwacje klientów"></input></form>
                 <form action="zarezerwuj_pracownik.php" method="get">
                 <input type="submit" value="Zrób rezerwację"></input></form>

                 <?php
   $polaczenie->close();

 ?>
</div>
<h1>
<p><br />Zdjęcie nie przedstawia prawdziwego hotelu , źródło: https://q-cf.bstatic.com/images/hotel/max1024x768/216/216004253.jpg</p>
</h1>
</body>
</html>
