<?php
  session_start();
  ?>

  <link rel="stylesheet" href="style.css" type="text/css">
  <style>
  body { background-image: url("index.png");
  background-size: 1450px;
  }
  </style>
<?php
  if((isset($_SESSION['zalogowany'])) && ($_SESSION['zalogowany']==true)) // jesli jest uzytkownik zalogowany to przechodzimy do konta od razu
  {
    header('Location:konto.php');
    exit(); //nie wykonywać reszty kodu pod spodem, bo i tka przechodzimy do innego pliku .php
  }
 ?>

 <!DOCTYPE HTML>
 <html lang="pl">
 <head>
     <meta charset="utf-8" />
     <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
     <title> Logowanie </title>
</head>

<body>
  <br /><br />
  <br /><br />
  <form action="zaloguj.php" method="post">
<div id="container">
</form>
      Login: <br /> <input type="text" name="login" placeholder="login" onfocus="this.placeholder=''"  onblur="this.placeholder='login' "/> <br />
      Hasło: <br /> <input type="password" name="haslo" placeholder="hasło" onfocus="this.placeholder=''" onblur="this.placeholder='hasło' "/> <br /><br />
      <?php
        if(isset($_SESSION['blad']))  echo $_SESSION['blad']; // tylko jak ktoś próbował się zalogować to wyświetl błąd
        unset($_SESSION['blad']);

       ?>
    <input type ="submit" value="Zaloguj sie" />


  </form>
  <form action="rejestracja.php" method="get">
  <input type="submit" value="Załóż konto"></input>
</div>

  <h1>
  <p><br />Zdjęcie nie przedstawia prawdziwego hotelu , źródło: https://q-cf.bstatic.com/images/hotel/max1024x768/797/79726354.jpg</p>
</h1>


</body>
</html>
