<?php

  session_start(); // kazdy dokument korzydtajacy z sesji musi miec ta linijke, nie trzeba takiego polaczenia sesji konczyc, tak jka mysqli

  if((!isset($_POST['login'])) || (!isset($_POST['haslo'])))  //jesli nie jest ustawiona zmienna login i haslo w ogoolnej tablicy post to przechodzimy do formularza logowania
  {
    header('Location: index.php');
    exit();
  }

  require_once "connect.php"; //załączenie pliku ; require_once bo jesli nie uda sie dolaczyc pliku to nie zostanie "zaledwie" wygenerowane ostrzeżenie tylko zatrzymamy skrypt, bo to groźne, "once" bo php najpierw sprawdzi czy nie został wcześniej plik wczytany i jeśli dołączone wcześniej to nie dołącza ponownie

  $polaczenie = @new mysqli($host,$db_user,$db_password,$db_name); //@- wycisza błędy spowodowane przez dalsze instruckje //ustanowienie polaczenia przez mysqli przez przesłanie danych //rezerwuje nowa pamiec, a mysqli to metoda

  if ($polaczenie->connect_errno!=0)
  {
     echo "Error: ".$polaczenie->connect_errno ." Opis: ".$polaczenie->connect_error; // jesli blad to pokazujemy error number (errno) oraz opis (connect_error)

  }
  else
  {
    $login = $_POST['login'];
    $haslo = $_POST['haslo'];

    $login= htmlentities($login, ENT_QUOTES, "UTF-8"); //przepuszczenie podanego loginu i hasla przez htmlentites, co blokuje mysql injection, bo rozklada tresc zapytania na elementy tekstu a nie polecenie w jakimś języku

    #$sql = "SELECT * FROM konta WHERE login='$login' AND hasło='$haslo'"; i wtedy polaczenie->query($sql)
    // zamiast tego wyżej %s- oznaczenie miejsca gdzie bedzie zmienna, s-string, pierwszy %s to pierwszy argument podany po przecinku, drugi to drugi po przecinku,
    // tak też można, testowo
    if ($rezultat = @$polaczenie->query(sprintf("SELECT * FROM konta WHERE login='%s'",
    mysqli_real_escape_string($polaczenie,$login))))
    {
      $ilu_userow = $rezultat->num_rows; //sprawdzanie czy nasze query coś znalazło (użytkownika w bazie)
      if($ilu_userow>0)
      {
          $wiersz = $rezultat->fetch_assoc();

          if (password_verify($haslo, $wiersz['hasło']) OR $haslo=$wiersz['hasło']) // jest OR ale w tabeli jest hash, w przypadku tworzenia konta w mysql trzeba wybrać MD5 hashowanie! tak ok!
          {
            $_SESSION['zalogowany']=true;
            $_SESSION['id']=$wiersz['nr_id_konta'];
            $_SESSION['login']=$wiersz['login'];
            $_SESSION['email']=$wiersz['email'];
            $_SESSION['haslo']=$wiersz['hasło'];

            unset($_SESSION['blad']);
            // dodanie sprawdzania bitu pracownika
            if ($wiersz['pracownik']=='1')
            {
             $_SESSION['zalogowany_pracownik']=true;
              header('Location:konto_pracownik.php');
            }
            else{
              header('Location: konto.php');
            }

          }
          else
          {
            $_SESSION['blad']='<span style="color:red">Nieprawidlowy hash!</span>';
            header('Location:index.php');
          }
      } else
        {
          $_SESSION['blad']='<span style="color:red">Nieprawidlowy login lub hasło!</span>';
          header('Location:index.php');
        }

    }
    $polaczenie->close(); //zamkniecie polaczenie ( bo wyzej otwierane )
  }




 ?>
