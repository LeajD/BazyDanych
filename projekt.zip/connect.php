<?php //plik przechowujacy dane do serwera, oddzielamy pliki
  $host="localhost";
  $db_user="root"; //database user
  $db_password=""; //domyslnie bez hasla root
  $db_name="Hotel";


 ?>
