<?php
  session_start();

  session_unset(); //konczenie sesji ( do wylogowywania), nisczy wzysctkie zmienne sutawione w sesji
  header('Location: index.php');

?>
