<?php

session_start();
error_reporting(E_ERROR);
require_once "connect.php";
?>
<link rel="stylesheet" href="style.css" type="text/css">
<style>
body { background-image: url("31.png");
background-size: 1400px;
}
</style>
<?php

$nr_pokoju=$_POST['nr_pokoju'];

$miejsce_parkingowe=$_POST['miejsce_parkingowe'];
$miejsce_parkingowe= htmlentities($miejsce_parkingowe, ENT_QUOTES, "UTF-8");


$data_przyjazdu=$_POST['data_przyjazdu'];
$data_odjazdu=$_POST['data_odjazdu'];

$poprawnosc=0;
$p=0;
$b=0;
$id=$_SESSION['id'];
$login=$_SESSION['login'];
$date = date('Y-m-d', time());
$cos=0;


$tabela[22]=[];
$tabela2[19]=[];
 ?>

<!DOCTYPE HTML>
<html lang="pl">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title> Zarezerwuj pokój </title>
</head>

<body>
  <div id="container">
    <?php
        if(isset($_SESSION['zalogowany_pracownik']))
        {
          ?><form action="konto_pracownik.php" method="post">
            <input type="submit" value="Wróć "></input>
          <?php
        }
        else {
          ?><form action="index.php" method="post">
            <input type="submit" value="Wróć "></input>
          <?php
        }
         ?>
 <br /><br />

<?php
// sprawdzanie czy taki użytkownik ma uzupełnione dane ( wymagane aby złozyć rezerwacje !)
$polaczenie = @new mysqli($host,$db_user,$db_password,$db_name); //@- wycisza błędy spowodowane przez dalsze instruckje //ustanowienie polaczenia przez mysqli przez przesłanie danych //rezerwuje nowa pamiec, a mysqli to metoda
$sql="SELECT * FROM klienci WHERE nr_id_klienta='$id' ";
$rezultat=@$polaczenie->query($sql);
$wiersz = $rezultat->fetch_assoc();
$ile_rezultatow=$rezultat->num_rows; //zbieramy ilosc wystapien w tabeli
if($ile_rezultatow=='0')
{
  $_SESSION['error_klienci']="Brak uzupełnionych danych !";
  $cos=1;
}
if(isset($_SESSION['error_klienci']))
{
  echo '<div class="error" style="color:red">'.$_SESSION['error_klienci'].'</div>';
  unset($_SESSION['error_klienci']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic bledy

}

 ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 //                                                    TA CZĘŚĆ ODPOWIADA ZA SPRAWDZANIE DATY
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
?>
</form>
<form method="post">

      <?php
      session_start();
      if (($data_odjazdu < $data_przyjazdu && $data_przyjazdu>=$date && $data_odjazdu>=$date ) || ( $data_odjazdu > $data_przyjazdu && $data_przyjazdu<$date && $data_odjazdu<=$date ) || ( $data_odjazdu < $data_przyjazdu && $data_przyjazdu<=$date && $data_odjazdu<=$date ) || ( $data_odjazdu > $data_przyjazdu && $data_przyjazdu<$date && $data_odjazdu>=$date ) || ( $data_odjazdu < $data_przyjazdu && $data_przyjazdu>=$date && $data_odjazdu<=$date ))
        {
          $_SESSION['e_daty']="Data przyjazdu nie może być później niż odjazdu lub rezerwacja nie może odbyć się w minionym terminie!";
        }
       ?>

                       Data przyjazdu: <br /><input type="date" name="data_przyjazdu" value=<?php echo $data_przyjazdu; ?>  max="2020-12-30" /><br />
                       Data odjazdu: <br /><input type="date" name="data_odjazdu" value=<?php echo $data_odjazdu; ?>  max="2020-12-30" /><br /><br />
                                 <?php
                                 session_start();
                                 if(isset($_SESSION['e_daty']) )
                                 {
                                   #$wszystko_OK=false;
                                   echo '<div class="error" style="color:red">'.$_SESSION['e_daty'].'</div>';
                                   unset($_SESSION['e_daty']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic bledy
                                   ?><h3><a href ="zarezerwuj.php">'       Wybierz poprawną datę     </a><?php
                                   exit();
                                   ?>
                                   <?php

                                 }?>
                                 <input type="submit" value="Weryfikacja daty" name="submit"/>


<?php

 ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 //                                                    TA CZĘŚĆ ODPOWIADA ZA WYSWIETLANIE WOLNYCH POKOJÓW I PARKINGÓW
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
          session_start();
          if(isset($_POST['submit']) ) //jeśli nacisnięto submit
          {
            echo "---------------------------------------------<br />";
            echo "<h4>"." Wolne pokoje:<br /></h4>";
            echo "---------------------------------------------<br />";

          $polaczenie = @new mysqli($host,$db_user,$db_password,$db_name); //@- wycisza błędy spowodowane przez dalsze instruckje //ustanowienie polaczenia przez mysqli przez przesłanie danych //rezerwuje nowa pamiec, a mysqli to metoda

          $date = date('Y-m-d a', time());

          $sql="SELECT rezerwacje.nr_id_klienta,pokoje.nr_pokoju,pokoje.rodzaj_pokoju,pokoje.cena FROM pokoje,rezerwacje
          WHERE  (rezerwacje.nr_pokoju = pokoje.nr_pokoju && rezerwacje.status!='aktywny' && (('$data_przyjazdu'>rezerwacje.data_odjazdu && '$data_odjazdu'>rezerwacje.data_odjazdu) || ('$data_przyjazdu'<rezerwacje.data_przyjazdu && '$data_odjazdu'<rezerwacje.data_przyjazdu) )) ";
          $rezultat=@$polaczenie->query($sql);
          $ile_rezultatow=$rezultat->num_rows; //zbieramy ilosc wystapien w tabeli
          for($i=0; $i<$ile_rezultatow; $i++)
          {
            $wiersz[$i]=$rezultat->fetch_assoc();
            // sprawdzanie czy numer pokoju się powtarza, bo jeśli się powtarzał to potrafiło wyświetlić numer pokoju dostępny, bo np była późniejsza rezerwacja i jak sprawdzaliśmy wcześniejszą datą, to ona przechodziła nasz warunel - daty wcześniejsze , więc sprawdzanie ile razy wystąpiło i wyświetlanie tylko wtedy gdy ten pokój spełnia warunek ZAWSZE, TYLE RAZY ILE KWERENDA OBLICZY
            $test=$wiersz[$i]['nr_pokoju'];
            $zliczenia=0;
            $wyswietlone=0;
            $sql_liczba="SELECT * FROM rezerwacje WHERE $test=rezerwacje.nr_pokoju";
            $rezultat_liczby=@$polaczenie->query($sql_liczba);
            $ile_rezultatow_liczby=$rezultat_liczby->num_rows;


            for($x=0;$x<$ile_rezultatow;$x++)
            {
              if($wiersz[$x]['nr_pokoju']==$test)
                {
                    $zliczenia++;
                }
              if($ile_rezultatow_liczby==$zliczenia)
              {
                $zliczenia=0;
                if($nr_pokoju=$test)
                {
                  echo '<h3>'."Pokój numer: ".$wiersz[$i]['nr_pokoju']."<br/> ".$wiersz[$i]['rodzaj_pokoju'].", cena:  ".$wiersz[$i]['cena']."zł</h2>";
                }

              }
            }
          }
           ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
           ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
           ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
           //                                                    Ta część odpowiada za wyświetlanie wolnych parkingów
          ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
          ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
          echo "---------------------------------------------<br />";
          echo "<h4>"."Wolne miejsca parkingowe:</h4>";
          echo "---------------------------------------------<br />";

          $sql="SELECT rezerwacje.nr_parkingu,parkingi.miejsce, parkingi.id_parkingu,rezerwacje.data_przyjazdu,rezerwacje.data_odjazdu,rezerwacje.status,parkingi.cena FROM parkingi,rezerwacje
          WHERE  (rezerwacje.nr_parkingu = parkingi.id_parkingu && rezerwacje.status!='aktywny' && parkingi.status!='brak' && (('$data_przyjazdu'>rezerwacje.data_odjazdu && '$data_odjazdu'>rezerwacje.data_odjazdu) || ('$data_przyjazdu'<rezerwacje.data_przyjazdu && '$data_odjazdu'<rezerwacje.data_przyjazdu) )  )";
          $rezultat=@$polaczenie->query($sql);
          $ile_rezultatow=$rezultat->num_rows; //zbieramy ilosc wystapien w tabeli
          for($i=0; $i<$ile_rezultatow; $i++)
          {
            $wiersz[$i]=$rezultat->fetch_assoc();
            // sprawdzanie czy numer pokoju się powtarza, bo jeśli się powtarzał to potrafiło wyświetlić numer pokoju dostępny, bo np była późniejsza rezerwacja i jak sprawdzaliśmy wcześniejszą datą, to ona przechodziła nasz warunel - daty wcześniejsze , więc sprawdzanie ile razy wystąpiło i wyświetlanie tylko wtedy gdy ten pokój spełnia warunek ZAWSZE, TYLE RAZY ILE KWERENDA OBLICZY
            $test=$wiersz[$i]['nr_parkingu'];
            $zliczenia=0;
            $wyswietlone=0;
            $sql_liczba="SELECT * FROM rezerwacje WHERE $test=rezerwacje.nr_parkingu";
            $rezultat_liczby=@$polaczenie->query($sql_liczba);
            $ile_rezultatow_liczby=$rezultat_liczby->num_rows;

            for($x=0;$x<$ile_rezultatow;$x++)
            {
              if($wiersz[$x]['nr_parkingu']==$test)
                {
                    $zliczenia++;
                }
              if($ile_rezultatow_liczby==$zliczenia)
              {
                $zliczenia=0;
                  echo '<h3>'."Parking numer: ".$wiersz[$i]['miejsce']." cena: ".$wiersz[$i]['cena']."zł <br /></h3>";
              }
            }

          }
          echo "---------------------------------------------<br /><br/>";


          }
           ?>

                              Wybierz numer pokoju: <br /><input type="text" name="nr_pokoju"/><br />
                             Wybierz numer miejsca parkingowego: <br /><input type="text" name="miejsce_parkingowe"/><br />

                     <input type="submit" value="Rezerwuj" name="submit2"/>
                     </form>
<br />



    <?php
    session_start();



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//TA CZĘŚĆ ODPOWIADA ZA AKCJE PO NACIŚNIĘCIU REZERWUJ -- czyli sprawdzenie  czy pokój znajduje siee ( i zliczanie ile razy, aby w przypadku wielokrotnego wystapienia wziac pod uwage ze moze byc pokoj niedostepny w terminie oraz ten sam pokoj dostepnym w innym ) w tablicy która zbierała wolne pokoje i to samo z parkingami
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                        if(isset($_POST['submit2']))
                        {

                          $polaczenie = @new mysqli($host,$db_user,$db_password,$db_name); //@- wycisza błędy spowodowane przez dalsze instruckje //ustanowienie polaczenia przez mysqli przez przesłanie danych //rezerwuje nowa pamiec, a mysqli to metoda


                          $sql="SELECT rezerwacje.nr_id_klienta,pokoje.nr_pokoju,pokoje.rodzaj_pokoju,pokoje.cena FROM pokoje,rezerwacje
                          WHERE  (rezerwacje.nr_pokoju = pokoje.nr_pokoju && rezerwacje.status!='aktywny' && (('$data_przyjazdu'>rezerwacje.data_odjazdu && '$data_odjazdu'>rezerwacje.data_odjazdu) || ('$data_przyjazdu'<rezerwacje.data_przyjazdu && '$data_odjazdu'<rezerwacje.data_przyjazdu) )) ";
                          $rezultat=@$polaczenie->query($sql);
                          $ile_rezultatow=$rezultat->num_rows; //zbieramy ilosc wystapien w tabeli
                          for($i=0; $i<$ile_rezultatow; $i++)
                          {
                            $wiersz[$i]=$rezultat->fetch_assoc();
                            $test=$wiersz[$i]['nr_pokoju'];
                            $zliczenia=0;
                            $wyswietlone=0;
                            $sql_liczba="SELECT * FROM rezerwacje WHERE $test=rezerwacje.nr_pokoju";
                            $rezultat_liczby=@$polaczenie->query($sql_liczba);
                            $ile_rezultatow_liczby=$rezultat_liczby->num_rows;

                            for($x=0;$x<$ile_rezultatow;$x++)
                            {
                              if($wiersz[$x]['nr_pokoju']==$test)
                                {
                                    $zliczenia++;
                                }
                              if($ile_rezultatow_liczby==$zliczenia)
                              {
                                $zliczenia=0;
                                if($nr_pokoju=$test)
                                {
                                  $tabela[$b]=$wiersz[$i]['nr_pokoju'];
                                  $b++;
                                }

                              }
                            }
                          }
                          $nr_pokoju=$_POST['nr_pokoju'];

                          $sql="SELECT rezerwacje.nr_parkingu,parkingi.miejsce, parkingi.id_parkingu,rezerwacje.data_przyjazdu,rezerwacje.data_odjazdu,rezerwacje.status,parkingi.cena FROM parkingi,rezerwacje
                          WHERE  (rezerwacje.nr_parkingu = parkingi.id_parkingu && rezerwacje.status!='aktywny' && (('$data_przyjazdu'>rezerwacje.data_odjazdu && '$data_odjazdu'>rezerwacje.data_odjazdu) || ('$data_przyjazdu'<rezerwacje.data_przyjazdu && '$data_odjazdu'<rezerwacje.data_przyjazdu) )  )";
                          $rezultat=@$polaczenie->query($sql);
                          $ile_rezultatow=$rezultat->num_rows; //zbieramy ilosc wystapien w tabeli
                          for($i=0; $i<$ile_rezultatow; $i++)
                          {
                            $wiersz[$i]=$rezultat->fetch_assoc();
                            // sprawdzanie czy numer pokoju się powtarza, bo jeśli się powtarzał to potrafiło wyświetlić numer pokoju dostępny, bo np była późniejsza rezerwacja i jak sprawdzaliśmy wcześniejszą datą, to ona przechodziła nasz warunel - daty wcześniejsze , więc sprawdzanie ile razy wystąpiło i wyświetlanie tylko wtedy gdy ten pokój spełnia warunek ZAWSZE, TYLE RAZY ILE KWERENDA OBLICZY
                            $test=$wiersz[$i]['nr_parkingu'];
                            $zliczenia=0;
                            $wyswietlone=0;
                            $sql_liczba="SELECT * FROM rezerwacje WHERE $test=rezerwacje.nr_parkingu";
                            $rezultat_liczby=@$polaczenie->query($sql_liczba);
                            $ile_rezultatow_liczby=$rezultat_liczby->num_rows;

                            for($x=0;$x<$ile_rezultatow;$x++)
                            {
                              if($wiersz[$x]['nr_parkingu']==$test)
                                {
                                    $zliczenia++;
                                }
                              if($ile_rezultatow_liczby==$zliczenia)
                              {
                                $zliczenia=0;
                                  $tabela2[$p]=$wiersz[$i]['miejsce'];
                                  $p++;
                              }
                            }

                          }
                         // sprawdzanie poprawnosci pokojow czy
                         $rozmiar=count($tabela)+1; // pobieranie wartości
                         $nr_pokoju2=$nr_pokoju;
                         for($i=0;$i<$rozmiar+1;$i++)
                         {

                           if ($nr_pokoju2==$tabela[$i])
                           {
                             $poprawnosc++;
                           }

                         }
                         if($poprawnosc>'1')
                         {
                              $poprawnosc=1;
                             $_SESSION['e_nr_pokoju']="NIEPOPRAWNY NR POKOJU";

                         }
                         if(isset($_SESSION['e_nr_pokoju']))
                         {
                           unset($_SESSION['e_nr_pokoju']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic bledy
                         }

                         $rozmiar2=count($tabela2)+1;

                         $nr_parkingu2=$miejsce_parkingowe;

                         for($i=0;$i<$rozmiar2+1;$i++)
                         {

                           if($nr_parkingu2==$tabela2[$i])
                           {

                             $poprawnosc++;
                           }

                         }
                         if($poprawnosc>'2')
                         {
                           $poprawnosc=2;
                             $_SESSION['e_nr_pokoju']="NIEPOPRAWNY NR PARKINGU";

                         }

                      //sumujemy ceny za pokój i parking
                      $sql="SELECT * FROM pokoje WHERE nr_pokoju='$nr_pokoju'";
                      $rezultat=@$polaczenie->query($sql);
                      $wiersz=$rezultat->fetch_assoc();
                      $cena1=$wiersz['cena'];
                        $sql="SELECT * FROM parkingi WHERE miejsce='$miejsce_parkingowe'";
                        $rezultat=@$polaczenie->query($sql);
                        $wiersz=$rezultat->fetch_assoc();
                        $cena2=$wiersz['cena'];
                          $cena3=$cena1+$cena2;



    if($poprawnosc=='2' && !isset($_SESSION['zalogowany_pracownik']) && $cos!=1)
    {
          unset($_SESSION['brak_error_rezultatow']);
            if($miejsce_parkingowe==0)
            {
              $polaczenie->query("INSERT INTO `rezerwacje`( `nr_id_klienta`, `nr_pokoju`, `nr_parkingu`, `data_przyjazdu`, `data_odjazdu`, `cena`, `opłacone`, `status`) VALUES ( '$id', '$nr_pokoju', '0', '$data_przyjazdu', '$data_odjazdu', '$cena3', 'tak','tak')");
            }                                                                                              # tutaj
            $polaczenie->query("INSERT INTO `rezerwacje`( `nr_id_klienta`, `nr_pokoju`, `nr_parkingu`, `data_przyjazdu`, `data_odjazdu`, `cena`, `opłacone`, `status`) VALUES ( '$id', '$nr_pokoju','$miejsce_parkingowe', '$data_przyjazdu', '$data_odjazdu', '$cena3', 'tak','tak')");
            unset($_SESSION['error']); // wyciszam error, bo jak sie wypełni date i potem submituje to po wypełnieniu pokoju i parkingu nie pamięta że data jest wybrana
            $_SESSION['success']="Rezerwacja udana";
      }
      else {
          if(isset($_POST['submit2']))
        {
        $_SESSION['not_ok']=" Podałeś zły numer pokoju i parkingu lub jesteś pracownikiem.<br /> Jeśli jesteś klientem, uzupełnij swoje dane!";
        echo '<div class="error" style="color:RED">'.$_SESSION['not_ok'].'</div>';
        unset($_SESSION['not_ok']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic ble
        exit();
        }
        }
        $polaczenie->close();
        }

?>


<?php

if(isset($_SESSION['success']))
{
  #$wszystko_OK=false;
  echo '<div class="error" style="color:green">'.$_SESSION['success'].'</div>';
  unset($_SESSION['success']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic bledy
}


  unset($_SESSION['blad']);
  unset($_SESSION['e_status_pokoj']);
  unset($_SESSION['error']);
  unset($_SESSION['error_klienci']); // zeby przy nastepnym wyslaniu formularza mozna bylo poprawic bledy


 ?>
</div>
</body>
</html>
