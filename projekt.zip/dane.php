<?php
  session_start();
  require_once "connect.php";
  ?>
  <link rel="stylesheet" href="style.css" type="text/css">
  <style>
  body { background-image: url("31.png");
  background-size: 1400px;
  }
  </style>
<?php
  error_reporting(E_ERROR);


  $id=$_SESSION['id'];
  $polaczenie = @new mysqli($host,$db_user,$db_password,$db_name); //@- wycisza błędy spowodowane przez dalsze instruckje //ustanowienie polaczenia przez mysqli przez przesłanie danych //rezerwuje nowa pamiec, a mysqli to metoda
  $sql="SELECT * FROM klienci WHERE nr_id_klienta='$id'";
  $rezultat=@$polaczenie->query($sql);
  $wiersz=$rezultat->fetch_assoc();
  $sql2="SELECT * FROM konta WHERE nr_id_konta='$id'";
  $rezultat2=@$polaczenie->query($sql2);
  $wiersz2=$rezultat2->fetch_assoc();

 ?>

 <!DOCTYPE HTML>
 <html lang="pl">
 <head>
     <meta charset="utf-8" />
     <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
     <title> Twoje dane </title>
</head>

<body>
  <div id="container">
    <?php
        if(isset($_SESSION['zalogowany_pracownik']))
        {
          ?><form action="konto_pracownik.php" method="post">
            <input type="submit" value="Wróć "></input>
          <?php
        }
        else {
          ?><form action="index.php" method="post">
            <input type="submit" value="Wróć "></input>
          <?php
        }
         ?>
  <br /><br />
  <form method="post">
    Login:    <?php        echo $wiersz2['login']."<br />"; ?>
    Email:    <?php        echo $wiersz2['email']."<br /><br />"; ?>
      Imię:    <?php        echo $wiersz['imię']."<br />"; ?>
      Nazwisko:    <?php        echo $wiersz['nazwisko']."<br />"; ?>
      Nr_dowodu:    <?php        echo $wiersz['nr_dowodu']."<br />"; ?>
      Nr_telefonu:    <?php        echo $wiersz['nr_telefonu']."<br />"; ?>
      Język:    <?php        echo $wiersz['język']."<br />"; ?>

  </form>
</div>
  <?php
    $polaczenie->close();
  ?>

</body>
</html>
